import { ensureMatnrInOutputKeys } from '../fieldDefaults';
import { OutputFieldDefinition, fieldKey } from '../types/material';

function isWerksFieldName(name: string | undefined): boolean {
  const n = (name ?? '').toUpperCase();
  return n === 'WERKS' || n === 'WERKS_DISP';
}

/**
 * Columns for results table + Excel:
 * MATNR first, then WERKS (next to material), then remaining selected fields.
 */
export function resolveOutputColumns(
  allOutputFields: OutputFieldDefinition[] | undefined | null,
  activeOutputFields: string[] | null,
): OutputFieldDefinition[] | undefined {
  if (!allOutputFields) return undefined;

  const selected = (() => {
    if (!activeOutputFields) return allOutputFields;
    const keys = new Set(ensureMatnrInOutputKeys(activeOutputFields, allOutputFields));
    return allOutputFields.filter((f) => keys.has(fieldKey(f)));
  })();

  const matnr = selected.filter((f) => (f.fieldName ?? '').toUpperCase() === 'MATNR');
  const werks = selected.filter((f) => isWerksFieldName(f.fieldName));
  const rest = selected.filter(
    (f) => (f.fieldName ?? '').toUpperCase() !== 'MATNR' && !isWerksFieldName(f.fieldName),
  );
  return [...matnr, ...werks, ...rest];
}
